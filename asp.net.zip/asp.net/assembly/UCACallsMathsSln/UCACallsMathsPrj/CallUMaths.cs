﻿using System;
using UCLprjMath;

namespace UCACallsMathsPrj
{
    class CallUMaths
    {
        static void Main(string[] args)
        {
            UCIsArithmetic uca = new UCIsArithmetic();

            double d1 = uca.USum(0.5, 9);
            double d2 = UCIsArithmetic.UMinus(8, 3);
        }
    }
}
