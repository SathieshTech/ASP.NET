﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UCLprjMath
{
    public partial class UCIsArithmetic
    {

        public double USum(double x, double y)
        {
            return x + y;
        }
        public static double UMinus(double x, double y)
        {
            return x - y;
        }
    }
}
