﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UCLprjMath
{
    public partial class UCIsArithmetic
    {
        public void UMultiply(double x,double y,double z)
        {
            z = x * y;
        }
        public static void UDivide(double x,double y,double z)
        {
            z = x / y;
        }

    }
}
