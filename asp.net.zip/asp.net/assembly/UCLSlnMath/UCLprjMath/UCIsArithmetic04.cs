﻿using System;
using System.Collections.Generic;


namespace UCLprjMath
{
    public class UCIsSum
    {
        private Dictionary<int, double> dc = new Dictionary<int, double>();

        public double this[int keyname]
        {
            set
            {
                dc.Add(keyname, value);
            }
            get
            {
                try
                {
                    return dc[keyname];
                }
                catch(Exception e)
                {
                    Console.WriteLine(keyname + ":" + e.Message + "\n");
                    return -1;
                }
            }
        }
        public double[]UElements
        {
            get
            {
                double[] d = new double[dc.Count];
                dc.Values.CopyTo(d, 0);
                return d;
            }
        }

    }
}
/*
 C:\Windows\System32>cd "C:\.NET PROGRAMS\classes\asp.net\assembly\UCLSlnMath\UCLprjMath\bin\Debug"

C:\.NET PROGRAMS\classes\asp.net\assembly\UCLSlnMath\UCLprjMath\bin\Debug>gacutil.exe /i UCLprjMath.dll
Microsoft (R) .NET Global Assembly Cache Utility.  Version 4.0.30319.0
Copyright (c) Microsoft Corporation.  All rights reserved.

Assembly successfully added to the cache
 */
