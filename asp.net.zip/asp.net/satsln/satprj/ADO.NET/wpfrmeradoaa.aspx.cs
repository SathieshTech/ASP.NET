﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Data.SqlClient;
using System.Data;

namespace satprj.ADO.NET
{
    public partial class wpfrmeradoaa : System.Web.UI.Page
    {
      
            string cnStr = null;
            SqlConnection SCnn = null;
            SqlCommand Scmd = null;
            SqlDataAdapter SDa = null;

            DataSet ds = null;
            DataTable dt = null;


            string qryIns = null, qryUpd = null, qryDel = null;
            string qrySela = null, qrySelb = null;

        
        public void uRefreshGridView()
        {
            try
            {
                ds = new DataSet();
                Scmd = new SqlCommand(qrySela, SCnn);
                SDa = new SqlDataAdapter(Scmd);

                SDa.Fill(ds, "ertbl");
                dt = ds.Tables["ertbl"];

                gvERList.DataSource = dt;
                gvERList.DataBind();

            }
            catch (Exception ex)
            {
                tbxMsg.Text = "Err.: " + ex.Message;
            }
        }
        public void uRunDMLQuery(string dmLst)
        {
            try
            {
                if (dmLst == "insert")
                {
                    Scmd = new SqlCommand(qryIns, SCnn);
                    Scmd.Parameters.AddWithValue("@SName", tbxSName.Text);
                    Scmd.Parameters.AddWithValue("@m1", tbxm1.Text);
                    Scmd.Parameters.AddWithValue("@m2", tbxm2.Text);
                }
                else if (dmLst == "update")
                {
                    Scmd = new SqlCommand(qryUpd, SCnn);
                    Scmd.Parameters.AddWithValue("@Rno", tbxRno.Text);
                    Scmd.Parameters.AddWithValue("@SName", tbxSName.Text);
                    Scmd.Parameters.AddWithValue("@m1", tbxm1.Text);
                    Scmd.Parameters.AddWithValue("@m2", tbxm2.Text);
                }
                else if (dmLst == "delete")
                {
                    Scmd = new SqlCommand(qryDel, SCnn);
                    Scmd.Parameters.AddWithValue("@Rno", tbxRno.Text);
                }
                LnkbtnCancel_Click(null, null);
                if (Scmd.ExecuteNonQuery() > 0)
                {
                    uRefreshGridView();
                    tbxMsg.Text = "Affected 1 row";
                }
            }
            catch (Exception ex)
            {
                tbxMsg.Text = "Err.:" + ex.Message;
            }
        }


        protected void Page_Load(object sender, EventArgs e)
        {
            qryIns = "Insert into ertbl";
            qryIns += " (SName,m1,m2)";
            qryIns += " values";
            qryIns += " (@SName,@m1,@m2)";

            qryUpd = "Update ertbl set";
            qryUpd += " SName=@sname,";
            qryUpd += " m1=@m1";
            qryUpd += " m2=@m2";
            qryUpd += " where Rno=@Rno";

            qryDel = "Delete from ertbl";
            qryDel += " where Rno=@Rno";

            qrySela = "select*from ertbl";

            qrySelb = "select*from ertbl";
            qrySelb += " where Rno=@Rno";

            cnStr = "Data Source=.;";
            cnStr += "Initial Catalog=saltxdb;";
            cnStr += "Integrated Security=true;";

            try
            {
                SCnn = new SqlConnection(cnStr);
                SCnn.Open();

                uRefreshGridView();
            }
            catch (Exception ex)
            {
                tbxMsg.Text = "Error: " + ex.Message;
            }
        }
        protected void gvERList_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            gvERList.PageIndex = e.NewPageIndex;
            uRefreshGridView();
        }
        protected void gvERList_SelectedIndexChanged(object sender, EventArgs e)
        {
            tbxRno.Text = gvERList.DataKeys[gvERList.SelectedRow.RowIndex].Value + "";
            LnkbtnFind_Click(null, null);
        }


        protected void LnkbtnCancel_Click(object sender, EventArgs e)
        {
            tbxRno.Text = null;
            tbxSName.Text = null;
            tbxm1.Text = null;
            tbxm2.Text = null;
            tbxtotal.Text = null;
            tbxAvg.Text = null;
           
        }

        protected void LnkbtnAdd_Click(object sender, EventArgs e)
        {
            uRunDMLQuery("insert");
        }

        protected void LnkbtnEdit_Click(object sender, EventArgs e)
        {
            string Rno = tbxRno.Text;
            uRunDMLQuery("update");
            tbxRno.Text = Rno;
            LnkbtnFind_Click(null, null);
        }

        protected void LnkbtnErase_Click(object sender, EventArgs e)
        {
            uRunDMLQuery("delete");
        }

        protected void LnkbtnFind_Click(object sender, EventArgs e)
        {
            try
            {
                Scmd = new SqlCommand(qrySelb, SCnn);
                Scmd.Parameters.AddWithValue("@Rno", tbxRno.Text);
                SDa = new SqlDataAdapter(Scmd);

                ds = new DataSet();
                SDa.Fill(ds, "ertbl");
                dt = ds.Tables["ertbl"];

                if (dt.Rows.Count != 1)
                {
                    LnkbtnCancel_Click(null, null);
                    return;
                }

                tbxSName.Text = dt.Rows[0]["SName"] + "";
                tbxm1.Text = dt.Rows[0]["m1"] + "";
                tbxm2.Text = dt.Rows[0]["m2"] + "";
                tbxtotal.Text = dt.Rows[0]["total"] + "";
                tbxAvg.Text = dt.Rows[0]["Average"] + "";

                if (dt.Rows[0]["result"].ToString() == "pass")
                {
                    ckbxfail.Checked = true;
                    ckbxfail.Text = "pass";
                }
                else
                {

                    ckbxfail.Checked = false;
                    ckbxfail.Text = "fail";
                }
  
                tbxMsg.Text = "Affected 1 Row";
            }
            catch (Exception ex)
            {
                tbxMsg.Text = "Err.: " + ex.Message;
            }
        }

       
        
    }
}