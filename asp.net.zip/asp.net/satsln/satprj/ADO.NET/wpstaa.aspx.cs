﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Data.SqlClient;
using System.Data;

namespace satprj
{
    public partial class wpstaa : System.Web.UI.Page
    {
        string cnStr = null;
        SqlConnection SCnn = null;
        SqlCommand Scmd = null;
        SqlDataAdapter SDa = null;

        DataSet ds = null;
        DataTable dt = null;


        string qryIns = null, qryUpd = null, qryDel = null;
        string qrySela = null, qrySelb = null;

        public void uRefreshGridView()
        {
            try
            {
                ds = new DataSet();
                Scmd = new SqlCommand(qrySela, SCnn);
                SDa = new SqlDataAdapter(Scmd);

                SDa.Fill(ds, "sttbl");
                dt = ds.Tables["sttbl"];

                gvEAList.DataSource = dt;
                gvEAList.DataBind();
          
            }catch(Exception ex)
            {
                tbxmsg.Text = "Err.: " + ex.Message;
            }
        }
        public void uRunDMLQuery(string dmLst)
        {
            try
            {
                if(dmLst == "insert")
                {
                    Scmd = new SqlCommand(qryIns, SCnn);
                    Scmd.Parameters.AddWithValue("@ename", tbxename.Text);
                    Scmd.Parameters.AddWithValue("@esal", tbxesal.Text);
                }
                else if(dmLst=="update")
                {
                    Scmd = new SqlCommand(qryUpd, SCnn);
                    Scmd.Parameters.AddWithValue("@eid", tbxeid.Text);
                    Scmd.Parameters.AddWithValue("@ename", tbxename.Text);
                    Scmd.Parameters.AddWithValue("@esal", tbxesal.Text);
                }
                else if(dmLst=="delete")
                {
                    Scmd = new SqlCommand(qryDel, SCnn);
                    Scmd.Parameters.AddWithValue("@eid", tbxeid.Text);
                }
                Lnkbtn1_Click(null, null);
                if(Scmd.ExecuteNonQuery() > 0)
                {
                    uRefreshGridView();
                    tbxmsg.Text = "Affected 1 row";
                }
            }catch(Exception ex)
            {
                tbxmsg.Text = "Err.:" + ex.Message;
            }
        }
        protected void Page_Load(object sender, EventArgs e)
        {
            qryIns = "Insert into sttbl";
            qryIns += " (ename,esal)";
            qryIns += " values";
            qryIns += " (@ename,@esal)";

            qryUpd = "Update sttbl set";
            qryUpd += " ename=@ename,";
            qryUpd += " esal=@esal";
            qryUpd += " where eid=@eid";

            qryDel = "Delete from sttbl";
            qryDel += " where eid=@eid";

            qrySela = "select*from sttbl";

            qrySelb = "select*from sttbl";
            qrySelb += " where eid=@eid";

            cnStr = "Data Source=.;";
            cnStr += "Initial Catalog=cmrdb;";
            cnStr += "Integrated Security=true;";

            try
            {
                SCnn = new SqlConnection(cnStr);
                SCnn.Open();

                uRefreshGridView();
            }catch(Exception ex)
            {
                tbxmsg.Text = "Error: " + ex.Message;
            }
            
        }
        protected void gvEAList_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            gvEAList.PageIndex = e.NewPageIndex;
            uRefreshGridView();
        }
        protected void gvEAList_SelectedIndexChanged(object sender, EventArgs e)
        {
            tbxeid.Text = gvEAList.DataKeys[gvEAList.SelectedRow.RowIndex].Value + "";
            Lnkbtn5_Click(null, null);
        }




        protected void Lnkbtn1_Click(object sender, EventArgs e)
        {
            tbxeid.Text = null;
            tbxename.Text = null;
            tbxesal.Text = null;
            tbxtax10.Text = null;
            tbxtax20.Text = null;
            tbxtax30.Text = null;
            tbxttax.Text = null;
            tbxnpay.Text = null;
            tbxmsg.Text = null;

        }

        

       

        protected void Lnkbtn2_Click(object sender, EventArgs e)
        {
            uRunDMLQuery("insert");
        }
        protected void Lnkbtn4_Click(object sender, EventArgs e)
        {
            string eid = tbxeid.Text;
            uRunDMLQuery("update");
            tbxeid.Text = eid;
            Lnkbtn5_Click(null, null);
        }


        protected void Lnkbtn3_Click(object sender, EventArgs e)
        {
            uRunDMLQuery("delete");
        }

        

        protected void Lnkbtn5_Click(object sender, EventArgs e)
        {
            try
            {
                Scmd = new SqlCommand(qrySelb, SCnn);
                Scmd.Parameters.AddWithValue("@eid", tbxeid.Text);
                SDa = new SqlDataAdapter(Scmd);

                ds = new DataSet();
                SDa.Fill(ds, "sttbl");
                dt = ds.Tables["sttbl"];

                if(dt.Rows.Count !=1)
                {
                    Lnkbtn1_Click(null, null);
                    return;
                }

                tbxename.Text = dt.Rows[0]["ename"] + "";
                tbxesal.Text = dt.Rows[0]["esal"] + "";
                tbxtax10.Text = dt.Rows[0]["tax10"] + "";
                tbxtax20.Text = dt.Rows[0]["tax20"] + "";
                tbxtax30.Text = dt.Rows[0]["tax30"] + "";
                tbxttax.Text = dt.Rows[0]["ttax"] + "";
                tbxnpay.Text = dt.Rows[0]["npay"] + "";

                tbxmsg.Text = "Affected 1 Row";
            }
            catch (Exception ex)
            {
                tbxmsg.Text = "Err.: " + ex.Message;
            }
        }
    }
}