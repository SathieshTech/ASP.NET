﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Data.SqlClient;
using System.Data;


namespace satprj.ADO.NET
{
    public partial class wpeaaa : System.Web.UI.Page
    {
        string cnStr = null;
        SqlConnection SCnn = null;
        SqlCommand Scmd = null;
        SqlDataAdapter SDa = null;

        DataSet ds = null;
        DataTable dt = null;


        string qryIns = null, qryUpd = null, qryDel = null;
        string qrySela = null, qrySelb = null;

        public void uRefreshGridView()
        {
            try
            {
                ds = new DataSet();
                Scmd = new SqlCommand(qrySela, SCnn);
                SDa = new SqlDataAdapter(Scmd);

                SDa.Fill(ds, "emp");
                dt = ds.Tables["emp"];

                gvList.DataSource = dt;
                gvList.DataBind();

            }
            catch (Exception ex)
            {
                Tbxmsg.Text = "Err.: " + ex.Message;
            }
        }
        public void uRunDMLQuery(string dmLst)
        {
            try
            {
                if (dmLst == "insert")
                {
                    Scmd = new SqlCommand(qryIns, SCnn);
                    Scmd.Parameters.AddWithValue("@ename", Tbxename.Text);
                    Scmd.Parameters.AddWithValue("@esal", Tbxesal.Text);
                }
                else if (dmLst == "update")
                {
                    Scmd = new SqlCommand(qryUpd, SCnn);
                    Scmd.Parameters.AddWithValue("@eid", Tbxeid.Text);
                    Scmd.Parameters.AddWithValue("@ename", Tbxename.Text);
                    Scmd.Parameters.AddWithValue("@esal", Tbxesal.Text);
                }
                else if (dmLst == "delete")
                {
                    Scmd = new SqlCommand(qryDel, SCnn);
                    Scmd.Parameters.AddWithValue("@eid", Tbxeid.Text);
                }
                Lnkbtn1_Click(null, null);
                if (Scmd.ExecuteNonQuery() > 0)
                {
                    uRefreshGridView();
                    Tbxmsg.Text = "Affected 1 row";
                }
            }
            catch (Exception ex)
            {
                Tbxmsg.Text = "Err.:" + ex.Message;
            }
        }
        protected void Page_Load(object sender, EventArgs e)
        {
            qryIns = "Insert into emp";
            qryIns += " (ename,esal)";
            qryIns += " values";
            qryIns += " (@ename,@esal)";

            qryUpd = "Update emp set";
            qryUpd += " ename=@ename,";
            qryUpd += " esal=@esal";
            qryUpd += " where eid=@eid";

            qryDel = "Delete from emp";
            qryDel += " where eid=@eid";

            qrySela = "select*from emp";

            qrySelb = "select*from emp";
            qrySelb += " where eid=@eid";

            cnStr = "Data Source=.;";
            cnStr += "Initial Catalog=satdb;";
            cnStr += "Integrated Security=true;";

            try
            {
                SCnn = new SqlConnection(cnStr);
                SCnn.Open();

                uRefreshGridView();
            }
            catch (Exception ex)
            {
                Tbxmsg.Text = "Error: " + ex.Message;
            }

        }
        protected void gvList_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            gvList.PageIndex = e.NewPageIndex;
            uRefreshGridView();
        }
        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            Tbxeid.Text = gvList.DataKeys[gvList.SelectedRow.RowIndex].Value + "";
            Lnkbtn5_Click(null, null);
        }



        protected void Lnkbtn1_Click(object sender, EventArgs e)
        {
        Tbxeid.Text = null;
        Tbxename.Text = null;
        Tbxesal.Text = null;
        Tbxhra.Text = null;
        Tbxda.Text = null;
        Tbxpf.Text = null;
        Tbxgpay.Text = null;
        Tbxnpay.Text = null;
        Tbxmsg.Text = null;
    }

        protected void Lnkbtn2_Click(object sender, EventArgs e)
        {
            uRunDMLQuery("insert");
        }

        protected void Lnkbtn3_Click(object sender, EventArgs e)
        {
            string eid = Tbxeid.Text;
            uRunDMLQuery("update");
            Tbxeid.Text = eid;
            Lnkbtn5_Click(null, null);
        }

        protected void Lnkbtn4_Click(object sender, EventArgs e)
        {
            uRunDMLQuery("delete");
        }

        protected void Lnkbtn5_Click(object sender, EventArgs e)
        {
            try
            {
                Scmd = new SqlCommand(qrySelb, SCnn);
                Scmd.Parameters.AddWithValue("@eid", Tbxeid.Text);
                SDa = new SqlDataAdapter(Scmd);

                ds = new DataSet();
                SDa.Fill(ds, "sttbl");
                dt = ds.Tables["sttbl"];

                if (dt.Rows.Count != 1)
                {
                    Lnkbtn1_Click(null, null);
                    return;
                }

                Tbxename.Text = dt.Rows[0]["ename"] + "";
                Tbxesal.Text = dt.Rows[0]["esal"] + "";
                Tbxhra.Text = dt.Rows[0]["HRA"] + "";
                Tbxda.Text = dt.Rows[0]["DA"] + "";
                Tbxpf.Text = dt.Rows[0]["PF"] + "";
                Tbxgpay.Text = dt.Rows[0]["gpay"] + "";
                Tbxnpay.Text = dt.Rows[0]["npay"] + "";

                Tbxmsg.Text = "Affected 1 Row";
            }
            catch (Exception ex)
            {
                Tbxmsg.Text = "Err.: " + ex.Message;
            }
        }

        
    }
}