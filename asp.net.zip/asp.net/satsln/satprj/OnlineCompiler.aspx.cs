﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace satprj
{
    public partial class OnlineCompiler : System.Web.UI.Page
    {
        SqlConnection sqlCn;
        SqlCommand sqlCmd;
        SqlDataAdapter sqlDA;

        DataSet ds;
        static string dqlQry;
        protected void Page_Load(object sender, EventArgs e)
        {
            tbxresultpane.Text = null;
            try
            {
                string s = ConfigurationManager.ConnectionStrings["cnsStrsathishdb"].ToString();
                    sqlCn = new SqlConnection(s);

            }catch(Exception ex)
            {
                tbxresultpane.Text = ex.Message;
            }

        }

        
        protected void BtnRun_Click(object sender, EventArgs e)
        {
            uRunQuery();
        }
        public void uRunQuery()
        {
            tbxresultpane.Text = null;
            gvResultpane.DataSource = null;
            gvResultpane.DataBind();
            string qry = tbxquerypane.Text;

            try
            {
                if(qry.ToLower().StartsWith("select"))
                {
                    dqlQry = qry;
                    uRefreshGridView();
                    return;
                }
                sqlCn.Open();
                sqlCmd = new SqlCommand(qry, sqlCn);

                int i = sqlCmd.ExecuteNonQuery();
                if(i>0)
                {
                    tbxresultpane.Text = i + " Row(s) affected";
                }else
                {
                    tbxresultpane.Text = "Command(S) complted succesfully";
                }
                sqlCn.Close();
            }catch(Exception e)
            {
                tbxresultpane.Text = e.Message;
            }
        }
        
        


       

        protected void gvResultpane_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            gvResultpane.PageIndex = e.NewPageIndex;
            uRefreshGridView();
        }

        public void uRefreshGridView()
        {
            tbxresultpane.Text = null;
            gvResultpane.DataSource = null;
            gvResultpane.DataBind();

            try
            {
                sqlCn.Open();
                sqlCmd = new SqlCommand(dqlQry, sqlCn);
                sqlDA = new SqlDataAdapter(sqlCmd);

                ds = new DataSet();
                sqlDA.Fill(ds);
                sqlCn.Close();

                gvResultpane.DataSource = ds;
                gvResultpane.DataBind();
                tbxresultpane.Text = "Command(S) complted succesfully";
            }catch(Exception e)
            {
                tbxresultpane.Text = e.Message;
            }
            
        }
    }
}