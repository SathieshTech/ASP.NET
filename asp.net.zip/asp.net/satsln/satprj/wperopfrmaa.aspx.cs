﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace satprj
{
    public partial class wperopfrmaa : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

            int rno = 0;
            int.TryParse(Request.QueryString["tbxRno"] ,out rno);
            string sname = Request.QueryString["tbxSName"];

            double m1 = 0;
            double.TryParse(Request.QueryString["tbxm1"], out m1);

            double m2 = 0;
            double.TryParse(Request.QueryString["tbxm2"], out m2);

            double total = m1 + m2;
            double avg = total / 2;
            bool result = m1 > 34.4 && m2 > 34.4;


            tbxRno.Text = rno + "";
            tbxSName.Text = sname;
            tbxM1.Text = m1 + "";
            tbxM2.Text = m2 + "";
            tbxtotal.Text =total + "";
            tbxavg.Text = avg + "";
            if(result)
            {
                Rdbtnpass.Checked = true;
            }else
            {
                Rdbtnfail.Checked = true;
            }
        }
    }
}