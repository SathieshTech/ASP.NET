﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace satprj
{
    public partial class wperfrmaa : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnCancel_Click(object sender, EventArgs e)
        {
            tbxRno.Text = null;
            tbxSName.Text = null;
            tbxm1.Text = null;
            tbxm2.Text = null;
            tbxtot.Text = null;
            tbxavg.Text = null;

            chkbxresult.Text = "Fail";
            chkbxresult.Checked = false;
        }

        protected void btnFind_Click(object sender, EventArgs e)
        {
            double m1 = 0, m2 = 0, total = 0, avg = 0;
            bool result = false;
            double.TryParse(tbxm1.Text, out m1);
            double.TryParse(tbxm2.Text, out m2);
            total = m1 + m2;
            avg = total / 2;
            result = m1 > 34.4 && m2 > 34.4;
            tbxtot.Text = total + "";
            tbxavg.Text = avg + "";
            chkbxresult.Checked = result;
            chkbxresult.Text = result ? "Pass" : "Fail";

        }
    }
}