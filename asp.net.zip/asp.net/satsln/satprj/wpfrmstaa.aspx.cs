﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace satprj
{
    public partial class wpfrmstaa : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnCancel_Click(object sender, EventArgs e)
        {
            Response.Redirect("wpfrmstaa.aspx");
        }

        protected void btnFind_Click(object sender, EventArgs e)
        {
            double esal = 0;
            double tax10 = 0, tax20 = 0, tax30 = 0, tottax = 0, npay = 0;
            double.TryParse(tbxesal.Text, out esal);
            if (esal <= 250000)
            {
                tax10 = 0;
                tax20 = 0;
                tax30 = 0;
            }
            else if (esal > 250000 && esal <= 500000)
            {
                tax10 = (esal - 250000) * 10.0 / 100;
            }
            else if (esal > 500000 && esal <= 1000000)
            {
                tax10 = 25000;
                tax20 = (esal - 500000) * 20.0 / 100;
            }
            else if (esal > 100000)
            {
                tax10 = 25000;
                tax20 = 100000;
                tax30 = (esal - 1000000) * 30.0 / 100;
            }

            tottax = tax10 + tax20 + tax30;
            npay = esal - tottax;
            tbxtax10.Text = tax10 + "";
            tbxtax20.Text = tax20 + "";
            tbxtax30.Text = tax30 + "";
            tbxtottax.Text = tottax + "";
            tbxnpay.Text = npay + "";
        
    
}
    }
}