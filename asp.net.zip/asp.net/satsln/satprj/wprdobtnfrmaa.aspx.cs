﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace satprj
{
    public partial class wprdobtnfrmaa : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            rdobtnmsp.Checked = false;
            rdobtnmsa.Checked = false;

            rdobtnasp.Checked = false;
            rdobtnasa.Checked = false;

            Lblop.Text = "wait....";
        }

        protected void RadioButton1_CheckedChanged(object sender, EventArgs e)
        {

        }

        protected void btnFind_Click(object sender, EventArgs e)
        {
            string s = "";
            if(rdobtnmsp.Checked)
            {
                s = "morning session" + rdobtnmsp.Text;
            }else if(rdobtnmsa.Checked)
            {
                s = "morning session" + rdobtnmsa.Text;
            }
            if(rdobtnasp.Checked)
            {
                s+= "<br> afternoon session" + rdobtnasp.Text;
            }else if(rdobtnasa.Checked)
            {
                s += "<br> afternoon session" + rdobtnasa.Text;
            }

            Lblop.Text = s;
        }
    }
}