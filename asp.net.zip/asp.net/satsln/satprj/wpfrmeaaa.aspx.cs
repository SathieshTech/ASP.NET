﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace satprj
{
    public partial class wpfrmeaaa : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnCancel_Click(object sender, EventArgs e)
        {
            Response.Redirect("wpfrmeaaa.aspx");

        }

        protected void btnFind_Click(object sender, EventArgs e)
        {
            double esal = 0;
            double hra = 0, da = 0, pf = 0, gpay = 0, npay = 0;
            double.TryParse(tbxesal.Text, out esal);
            hra = esal * 20.0 / 100;
            da = esal * 15.0 / 100;
            pf = esal * 35.0 / 100;
            gpay = hra + da + pf;
            npay = gpay - pf;
            tbxhra.Text = hra + "";
            tbxda.Text = da + "";
            tbxpf.Text = pf + "";
            tbxgpay.Text = gpay + "";
            tbxnpay.Text = npay + "";
        }
    }
}