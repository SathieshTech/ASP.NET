﻿namespace wfsatprj
{
    partial class wferaa
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Lblrno = new System.Windows.Forms.Label();
            this.Lblsname = new System.Windows.Forms.Label();
            this.Lblm1 = new System.Windows.Forms.Label();
            this.Lblm2 = new System.Windows.Forms.Label();
            this.Lbltotal = new System.Windows.Forms.Label();
            this.Lblavg = new System.Windows.Forms.Label();
            this.Lblresult = new System.Windows.Forms.Label();
            this.tbxRno = new System.Windows.Forms.TextBox();
            this.tbxSname = new System.Windows.Forms.TextBox();
            this.tbxM1 = new System.Windows.Forms.TextBox();
            this.tbxM2 = new System.Windows.Forms.TextBox();
            this.tbxTotal = new System.Windows.Forms.TextBox();
            this.tbxAvg = new System.Windows.Forms.TextBox();
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnFind = new System.Windows.Forms.Button();
            this.chkbxresult = new System.Windows.Forms.CheckBox();
            this.SuspendLayout();
            // 
            // Lblrno
            // 
            this.Lblrno.AutoSize = true;
            this.Lblrno.Location = new System.Drawing.Point(41, 33);
            this.Lblrno.Name = "Lblrno";
            this.Lblrno.Size = new System.Drawing.Size(40, 13);
            this.Lblrno.TabIndex = 0;
            this.Lblrno.Text = "Roll no";
            // 
            // Lblsname
            // 
            this.Lblsname.AutoSize = true;
            this.Lblsname.Location = new System.Drawing.Point(41, 64);
            this.Lblsname.Name = "Lblsname";
            this.Lblsname.Size = new System.Drawing.Size(75, 13);
            this.Lblsname.TabIndex = 1;
            this.Lblsname.Text = "Student Name";
            // 
            // Lblm1
            // 
            this.Lblm1.AutoSize = true;
            this.Lblm1.Location = new System.Drawing.Point(41, 95);
            this.Lblm1.Name = "Lblm1";
            this.Lblm1.Size = new System.Drawing.Size(40, 13);
            this.Lblm1.TabIndex = 2;
            this.Lblm1.Text = "Mark-1";
            // 
            // Lblm2
            // 
            this.Lblm2.AutoSize = true;
            this.Lblm2.Location = new System.Drawing.Point(41, 125);
            this.Lblm2.Name = "Lblm2";
            this.Lblm2.Size = new System.Drawing.Size(40, 13);
            this.Lblm2.TabIndex = 3;
            this.Lblm2.Text = "Mark-2";
            // 
            // Lbltotal
            // 
            this.Lbltotal.AutoSize = true;
            this.Lbltotal.Location = new System.Drawing.Point(41, 157);
            this.Lbltotal.Name = "Lbltotal";
            this.Lbltotal.Size = new System.Drawing.Size(31, 13);
            this.Lbltotal.TabIndex = 4;
            this.Lbltotal.Text = "Total";
            // 
            // Lblavg
            // 
            this.Lblavg.AutoSize = true;
            this.Lblavg.Location = new System.Drawing.Point(41, 183);
            this.Lblavg.Name = "Lblavg";
            this.Lblavg.Size = new System.Drawing.Size(47, 13);
            this.Lblavg.TabIndex = 5;
            this.Lblavg.Text = "Average";
            // 
            // Lblresult
            // 
            this.Lblresult.AutoSize = true;
            this.Lblresult.Location = new System.Drawing.Point(41, 214);
            this.Lblresult.Name = "Lblresult";
            this.Lblresult.Size = new System.Drawing.Size(37, 13);
            this.Lblresult.TabIndex = 6;
            this.Lblresult.Text = "Result";
            // 
            // tbxRno
            // 
            this.tbxRno.Enabled = false;
            this.tbxRno.Location = new System.Drawing.Point(154, 26);
            this.tbxRno.Name = "tbxRno";
            this.tbxRno.Size = new System.Drawing.Size(175, 20);
            this.tbxRno.TabIndex = 7;
            // 
            // tbxSname
            // 
            this.tbxSname.Location = new System.Drawing.Point(154, 57);
            this.tbxSname.Name = "tbxSname";
            this.tbxSname.Size = new System.Drawing.Size(175, 20);
            this.tbxSname.TabIndex = 8;
            // 
            // tbxM1
            // 
            this.tbxM1.Location = new System.Drawing.Point(154, 88);
            this.tbxM1.Name = "tbxM1";
            this.tbxM1.Size = new System.Drawing.Size(175, 20);
            this.tbxM1.TabIndex = 9;
            // 
            // tbxM2
            // 
            this.tbxM2.Location = new System.Drawing.Point(154, 118);
            this.tbxM2.Name = "tbxM2";
            this.tbxM2.Size = new System.Drawing.Size(175, 20);
            this.tbxM2.TabIndex = 10;
            this.tbxM2.TextChanged += new System.EventHandler(this.textBox4_TextChanged);
            // 
            // tbxTotal
            // 
            this.tbxTotal.Location = new System.Drawing.Point(154, 150);
            this.tbxTotal.Name = "tbxTotal";
            this.tbxTotal.ReadOnly = true;
            this.tbxTotal.Size = new System.Drawing.Size(175, 20);
            this.tbxTotal.TabIndex = 11;
            // 
            // tbxAvg
            // 
            this.tbxAvg.Location = new System.Drawing.Point(154, 176);
            this.tbxAvg.Name = "tbxAvg";
            this.tbxAvg.ReadOnly = true;
            this.tbxAvg.Size = new System.Drawing.Size(175, 20);
            this.tbxAvg.TabIndex = 12;
            // 
            // btnCancel
            // 
            this.btnCancel.Location = new System.Drawing.Point(154, 252);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(75, 23);
            this.btnCancel.TabIndex = 14;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnFind
            // 
            this.btnFind.Location = new System.Drawing.Point(254, 251);
            this.btnFind.Name = "btnFind";
            this.btnFind.Size = new System.Drawing.Size(75, 23);
            this.btnFind.TabIndex = 15;
            this.btnFind.Text = "Find";
            this.btnFind.UseVisualStyleBackColor = true;
            this.btnFind.Click += new System.EventHandler(this.btnFind_Click);
            // 
            // chkbxresult
            // 
            this.chkbxresult.AutoSize = true;
            this.chkbxresult.Enabled = false;
            this.chkbxresult.Location = new System.Drawing.Point(154, 214);
            this.chkbxresult.Name = "chkbxresult";
            this.chkbxresult.Size = new System.Drawing.Size(42, 17);
            this.chkbxresult.TabIndex = 16;
            this.chkbxresult.Text = "Fail";
            this.chkbxresult.UseVisualStyleBackColor = true;
            // 
            // wferaa
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(624, 353);
            this.Controls.Add(this.chkbxresult);
            this.Controls.Add(this.btnFind);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.tbxAvg);
            this.Controls.Add(this.tbxTotal);
            this.Controls.Add(this.tbxM2);
            this.Controls.Add(this.tbxM1);
            this.Controls.Add(this.tbxSname);
            this.Controls.Add(this.tbxRno);
            this.Controls.Add(this.Lblresult);
            this.Controls.Add(this.Lblavg);
            this.Controls.Add(this.Lbltotal);
            this.Controls.Add(this.Lblm2);
            this.Controls.Add(this.Lblm1);
            this.Controls.Add(this.Lblsname);
            this.Controls.Add(this.Lblrno);
            this.Enabled = false;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "wferaa";
            this.ShowIcon = false;
            this.Text = "wferaa";
            this.Load += new System.EventHandler(this.wferaa_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label Lblrno;
        private System.Windows.Forms.Label Lblsname;
        private System.Windows.Forms.Label Lblm1;
        private System.Windows.Forms.Label Lblm2;
        private System.Windows.Forms.Label Lbltotal;
        private System.Windows.Forms.Label Lblavg;
        private System.Windows.Forms.Label Lblresult;
        private System.Windows.Forms.TextBox tbxRno;
        private System.Windows.Forms.TextBox tbxSname;
        private System.Windows.Forms.TextBox tbxM1;
        private System.Windows.Forms.TextBox tbxM2;
        private System.Windows.Forms.TextBox tbxTotal;
        private System.Windows.Forms.TextBox tbxAvg;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnFind;
        private System.Windows.Forms.CheckBox chkbxresult;
    }
}