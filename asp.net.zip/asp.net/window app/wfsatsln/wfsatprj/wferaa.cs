﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace wfsatprj
{
    public partial class wferaa : Form
    {
        public wferaa()
        {
            InitializeComponent();
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            tbxRno.Text = null;
            tbxSname.Text = null;
            tbxM1.Text = null;
            tbxM2.Text = null;
            tbxTotal.Text = null;
            tbxAvg.Text = null;

            chkbxresult.Text = "Fail";
            chkbxresult.Checked = false;
        }

        private void btnFind_Click(object sender, EventArgs e)
        {
            double m1 = 0, m2 = 0, total = 0, avg = 0;
            bool result = false;

            double.TryParse(tbxM1.Text, out m1);
            double.TryParse(tbxM2.Text, out m2);

            total = m1 + m2;
            avg = total / 2;
            result = m1 > 34.4 && m2 > 34.4;

            tbxTotal.Text = total + "";
            tbxAvg.Text = avg + "";

            chkbxresult.Checked = result;
            chkbxresult.Text = result ? "Pass" : "Fail";


        }

        private void wferaa_Load(object sender, EventArgs e)
        {

        }
    }
}
